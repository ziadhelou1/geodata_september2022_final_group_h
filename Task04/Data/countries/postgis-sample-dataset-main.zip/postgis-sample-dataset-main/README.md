# postgis-sample-dataset
PostGIS sample dataset

Create a database and load the file using psql.
